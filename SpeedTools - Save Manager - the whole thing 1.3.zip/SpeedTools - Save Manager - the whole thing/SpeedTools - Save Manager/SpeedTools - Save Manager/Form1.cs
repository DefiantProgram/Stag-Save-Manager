﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Diagnostics;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;
using System.Media;

namespace SpeedTools___Save_Manager
{
    public partial class StagSaveManager : Form
    {
        public string addOrEdit = "";

        public TextBox filePath;
        string jsonString = "";

        public JSONWrapper wrapper = new JSONWrapper();

        public static string dirParameter = AppDomain.CurrentDomain.BaseDirectory + "Saves.JSON";

        AddEditSaveForm newForm;

        public bool sourceTrueDestinationFalse;

        public string selectedGameType;

        public StagSaveManager()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
            if (SavesList.SelectedIndex < wrapper.saves.Count && SavesList.SelectedIndex >= 0)
            {
                lb_FilepathToCopy.Text = wrapper.saves[SavesList.SelectedIndex].Filepath + " will be moved to: ";
            }
            */
        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            sourceTrueDestinationFalse = true;
            if (SavesList.SelectedIndex < wrapper.saves.Count && SavesList.SelectedIndex >= 0)
                OpenEditForm("Edit");
        }

        private void destBoxList_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
            if (SavesList.SelectedIndex < wrapper.saves.Count && SavesList.SelectedIndex >= 0)
            {
                lb_FilepathToCopy.Text = wrapper.saves[SavesList.SelectedIndex].Filepath + " will be moved to: ";
            }
            */
        }


        private void StagSaveManager_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedItem = "Hollow Knight";
            selectedGameType = "Hollow Knight";
            System.Diagnostics.Debug.WriteLine(dirParameter);
            try
            {
                wrapper = JsonConvert.DeserializeObject<JSONWrapper>(File.ReadAllText(dirParameter));
            }
            catch (Exception except)
            {
                Console.WriteLine(except);
            }

            UpdateList();
            UpdateDestinationList();
            newForm = new AddEditSaveForm(this);
        }

        private void bt_AddSave_Click(object sender, EventArgs e)
        {
            addOrEdit = "Add";

            if (selectedGameType == "Hollow Knight")
                newForm.theFilePath.Text = Environment.ExpandEnvironmentVariables(@"%AppData%\LocalLow\Team Cherry\Hollow Knight");
            else
                newForm.theFilePath.Text = "";
            newForm.customName.Text = "";
            sourceTrueDestinationFalse = true;
            newForm.Show();
        }

        private void bt_EditSave_Click(object sender, EventArgs e)
        {
            sourceTrueDestinationFalse = true;
            if (SavesList.SelectedIndex < wrapper.saves.Count && SavesList.SelectedIndex >= 0)
                OpenEditForm("Edit");
        }

        private void bt_RemoveSave_Click(object sender, EventArgs e)
        {
            if (SavesList.SelectedIndex < wrapper.saves.Count && SavesList.SelectedIndex >= 0)
                wrapper.saves.RemoveAt(SavesList.SelectedIndex);
            UpdateList();
        }

        private void bt_SetSave_Click(object sender, EventArgs e)
        {
            sourceTrueDestinationFalse = false;

            if (selectedGameType == "Hollow Knight")
                newForm.theFilePath.Text = Environment.ExpandEnvironmentVariables(@"%AppData%\LocalLow\Team Cherry\Hollow Knight");
            else
                newForm.theFilePath.Text = "";
            newForm.customName.Text = "";
            OpenEditForm("Add");

        }

        public void SaveWrapper()
        {
            jsonString = JsonConvert.SerializeObject(wrapper);
            File.WriteAllText(dirParameter, jsonString);
            UpdateList();
            UpdateDestinationList();
        }

        public void UpdateList()
        {
            SavesList.Items.Clear();
            SavesList.BeginUpdate();
            System.Object[] ItemObject = new System.Object[wrapper.saves.Count];
            for (int i = 0; i < wrapper.saves.Count; i++)
            {
                ItemObject[i] = wrapper.saves[i].SaveName;
            }
            SavesList.Items.AddRange(ItemObject);
            SavesList.EndUpdate();
        }

        public void UpdateDestinationList()
        {
            destBoxList.Items.Clear();
            destBoxList.BeginUpdate();
            System.Object[] ItemObject = new System.Object[wrapper.SD.Count];
            for (int i = 0; i < wrapper.SD.Count; i++)
            {
                ItemObject[i] = wrapper.SD[i].shortName;
            }
            destBoxList.Items.AddRange(ItemObject);
            destBoxList.EndUpdate();
        }


        private void bt_ImportSave_Click(object sender, EventArgs e)
        {
            if (SavesList.SelectedIndex < wrapper.saves.Count && SavesList.SelectedIndex >= 0
                &&
                destBoxList.SelectedIndex < wrapper.SD.Count && destBoxList.SelectedIndex >= 0)
            {
                string fileToCopy = wrapper.saves[SavesList.SelectedIndex].Filepath;
                string fileDestination = wrapper.SD[destBoxList.SelectedIndex].FilePath+"\\";


                // To copy a file to another location and
                // overwrite the destination file if it already exists.
                try
                {
                    System.IO.File.Copy(fileToCopy, fileDestination + Path.GetFileName(fileToCopy), true);                
                }
                catch (Exception except)
                {
                    Debug.WriteLine(except);
                }
                SystemSounds.Beep.Play();
            }


        }


        void OpenEditForm(string newAddOrEdit)
        {
            addOrEdit = newAddOrEdit;
            if (sourceTrueDestinationFalse)
            {
                if (addOrEdit == "Edit")
                {
                    if (SavesList.SelectedIndex < wrapper.saves.Count && SavesList.SelectedIndex >= 0)
                    {
                        newForm.customName.Text = wrapper.saves[SavesList.SelectedIndex].SaveName;
                        newForm.theFilePath.Text = wrapper.saves[SavesList.SelectedIndex].Filepath;
                        wrapper.saves.RemoveAt(SavesList.SelectedIndex);

                        newForm.Show();
                    }
                }
                else
                {
                    newForm.customName.Text = "";
                    newForm.Show();
                }
            }
            else
            {
                if (addOrEdit == "Edit")
                {
                    if (destBoxList.SelectedIndex < wrapper.SD.Count && destBoxList.SelectedIndex >= 0)
                    {
                        newForm.customName.Text = wrapper.SD[destBoxList.SelectedIndex].shortName;
                        newForm.theFilePath.Text = wrapper.SD[destBoxList.SelectedIndex].FilePath;
                        wrapper.saves.RemoveAt(destBoxList.SelectedIndex);

                        newForm.Show();
                    }
                }
                else
                {
                    newForm.customName.Text = "";
                    newForm.Show();
                }
            }
        }

        //Remove Destination
        private void button2_Click(object sender, EventArgs e)
        {
            if (destBoxList.SelectedIndex < wrapper.SD.Count && destBoxList.SelectedIndex >= 0)
                wrapper.SD.RemoveAt(destBoxList.SelectedIndex);
            UpdateDestinationList();
        }

        private void bt_EditDest_Click(object sender, EventArgs e)
        {
            sourceTrueDestinationFalse = false;
            if (destBoxList.SelectedIndex < wrapper.SD.Count && destBoxList.SelectedIndex >= 0)
            {
                newForm.customName.Text = wrapper.SD[destBoxList.SelectedIndex].shortName;
                newForm.theFilePath.Text = wrapper.SD[destBoxList.SelectedIndex].FilePath;
                wrapper.SD.RemoveAt(destBoxList.SelectedIndex);

                newForm.Show();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedGameType = comboBox1.SelectedItem.ToString();
        }

        private void destBoxList_DoubleClick(object sender, EventArgs e)
        {
            sourceTrueDestinationFalse = false;
            if (destBoxList.SelectedIndex < wrapper.SD.Count && destBoxList.SelectedIndex >= 0)
            {
                OpenEditForm("Edit");
            }
        }
    }

    [System.Serializable]
    public class JSONWrapper
    {
        public List<Save> saves = new List<Save>();
        public List<SaveDestination> SD = new List<SaveDestination>();
    }


    [System.Serializable]
    public class Save
    {
        public string SaveName;
        public string Filepath;

        public Save(string newSaveName, string newFilePath)
        {
            SaveName = newSaveName;
            Filepath = newFilePath;
        }
    }

    //Where the saves are transported to
    [System.Serializable]
    public class SaveDestination
    {
        public string FilePath;
        public string shortName;

        public SaveDestination(string newFilePath, string newShortName)
        {
            FilePath = newFilePath;
            shortName = newShortName;
        }
    }
}
