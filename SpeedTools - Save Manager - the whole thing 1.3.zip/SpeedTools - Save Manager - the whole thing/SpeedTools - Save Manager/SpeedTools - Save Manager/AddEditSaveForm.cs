﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;
using Newtonsoft.Json.Serialization;

namespace SpeedTools___Save_Manager
{
    public partial class AddEditSaveForm : Form
    {
        StagSaveManager theSSM;
        string fileDestination;
        public TextBox customName;
        public TextBox theFilePath;
        string dirShortCut = "";

        public AddEditSaveForm()
        {
            InitializeComponent();
        }

        public AddEditSaveForm(StagSaveManager ssm)
        {
            InitializeComponent();
            customName = customSaveName;
            theFilePath = filePath;
            theSSM = ssm;
            lb_AddOrEdit.Text = ssm.addOrEdit;
        }

        //Finish
        private void button2_Click(object sender, EventArgs e)
        {
            if (customName.Text != "")
            {
                if (theSSM.sourceTrueDestinationFalse)
                {
                    if (theSSM.wrapper.saves.Find(x => x.SaveName == customName.Text) == null)
                    {                       
                        theSSM.wrapper.saves.Add(new Save(customName.Text, filePath.Text));
                        theSSM.SaveWrapper();
                    }
                    else
                    {
                        theSSM.wrapper.saves[theSSM.wrapper.saves.FindIndex(x => x.SaveName == customName.Text)].Filepath = filePath.Text;
                        theSSM.UpdateList();
                    }
                }
                else
                {
                    if (theSSM.wrapper.SD.Find(x => x.shortName == customName.Text) == null)
                    {
                        theSSM.wrapper.SD.Add(new SaveDestination(filePath.Text, customName.Text));
                        theSSM.SaveWrapper();
                    }
                    else
                    {
                        theSSM.wrapper.SD[theSSM.wrapper.SD.FindIndex(x => x.shortName == customName.Text)].FilePath = filePath.Text;
                        theSSM.UpdateDestinationList();
                    }
                }
            }
            Hide();
        }

        //Browse
        private void button1_Click(object sender, EventArgs e)
        {
            if (theSSM.sourceTrueDestinationFalse)
            {
                OpenFileDialog openFileDialog1 = new OpenFileDialog
                {

                    InitialDirectory = dirShortCut == "" ? @"C:\" : dirShortCut,
                    Title = "Select Save File",

                    CheckFileExists = true,
                    CheckPathExists = true,

                    DefaultExt = "txt",
                    Filter = "",
                    FilterIndex = 2,
                    RestoreDirectory = true,

                    ReadOnlyChecked = true,
                    ShowReadOnly = true
                };

                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    dirShortCut = openFileDialog1.FileName;
                    filePath.Text = openFileDialog1.FileName;
                    fileDestination = openFileDialog1.FileName;
                }

            }
            else
            {
                string path;
                FolderBrowserDialog folderDlg = new FolderBrowserDialog();

                folderDlg.RootFolder = Environment.SpecialFolder.Desktop;
                if (theSSM.selectedGameType == "Hollow Knight")
                {
                    path = Environment.ExpandEnvironmentVariables(@"%AppData%\LocalLow\Team Cherry\Hollow Knight");
                }
                else
                    path = @"C:\";
                System.Diagnostics.Debug.WriteLine(path);

                folderDlg.ShowNewFolderButton = true;
                // Show the FolderBrowserDialog.  
                DialogResult result = folderDlg.ShowDialog();
                if (result == DialogResult.OK)
                {
                    filePath.Text = folderDlg.SelectedPath;
                    //wrapper.SD.FilePath = folderDlg.SelectedPath;                
                    Environment.SpecialFolder root = folderDlg.RootFolder;
                }


            }

        }
    }
}
